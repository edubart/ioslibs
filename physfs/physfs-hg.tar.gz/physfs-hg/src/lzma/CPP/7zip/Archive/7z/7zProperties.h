// 7zProperties.h

#ifndef __7Z_PROPERTIES_H
#define __7Z_PROPERTIES_H

#include "../../PropID.h"

namespace NArchive {
namespace N7z {

enum
{
  kpidPackedSize0 = kpidUserDefined,
  kpidPackedSize1, 
  kpidPackedSize2,
  kpidPackedSize3,
  kpidPackedSize4
};

}}

#endif
