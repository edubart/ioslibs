// PropIDUtils.h

#ifndef __PROPIDUTILS_H
#define __PROPIDUTILS_H

#include "Common/MyString.h"

UString ConvertPropertyToString(const PROPVARIANT &propVariant, PROPID propID, bool full = true);

#endif
