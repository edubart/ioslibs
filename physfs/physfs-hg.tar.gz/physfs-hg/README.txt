
PhysicsFS; a portable, flexible file i/o abstraction.

  http://icculus.org/physfs/

Please see the docs directory for documentation, licensing, and information.

